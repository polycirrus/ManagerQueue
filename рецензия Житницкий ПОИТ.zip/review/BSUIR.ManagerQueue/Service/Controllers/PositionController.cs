﻿namespace BSUIR.ManagerQueue.Service.Controllers
{
    using BSUIR.ManagerQueue.Data.Model;

    public class PositionController : BaseEntityController<Position>
    {
    }
}
