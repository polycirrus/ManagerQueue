﻿using Microsoft.AspNet.Identity.EntityFramework;

namespace BSUIR.ManagerQueue.Data.Model
{
    public class UserClaim : IdentityUserClaim<int>, IEntity
    {
    }
}
