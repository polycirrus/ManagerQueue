﻿using Microsoft.AspNet.Identity.EntityFramework;

namespace BSUIR.ManagerQueue.Data.Model
{
    public class UserRole : IdentityUserRole<int>
    {
    }
}
