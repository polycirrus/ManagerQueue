﻿namespace BSUIR.ManagerQueue.Infrastructure
{
    public static class RoleNames
    {
        public const string Secretary = "Secretary";
        public const string Vice = "Vice";
        public const string Manager = "Manager";
        public const string Administrator = "Administrator";
    }
}
